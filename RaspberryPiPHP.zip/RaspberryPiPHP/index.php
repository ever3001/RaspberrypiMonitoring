<!DOCTYPE html>
<html lang="fr">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Projet domotique LPAII 2015-2016">
    <meta name="author" content="ATILANO_EVER">

    <title>Pi Controller</title>

    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">

    <!-- Custom Fonts -->
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css" type="text/css">

    <!-- Plugin CSS -->
    <link rel="stylesheet" href="css/animate.min.css" type="text/css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/creative.css" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div class="container">
        <div class="row">
            <div class="col-md-offset-5 col-md-2">
                <button type="button" class="btn btn-primary btn-lg" id="clickON">ON</button>
                <button type="button" class="btn btn-primary btn-lg" id="clickOFF">OFF</button>
            </div>
        </div>
    </div>


    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/jquery.fittext.js"></script>
    <script src="js/wow.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/creative.js"></script>
    
    <script type="text/javascript">
        $(document).ready(function(){
            $('#clickON').click(function(){
                var a = new XMLHttpRequest();
                a.open("GET","pinOn.php");
                a.onreadystatechange=function(){
                    if(a.readyState==4){
                        if(a.status == 200){
                            
                        }
                        else alert("HTTP ERROR");
                    }
                }
                a.send();
            });
            
            $('#clickOFF').click(function(){
                var a = new XMLHttpRequest();
                a.open("GET","pinOff.php");
                a.onreadystatechange=function(){
                    if(a.readyState==4){
                        if(a.status == 200){
                            
                        }
                        else alert("HTTP ERROR");
                    }
                }
                a.send();
            });
        });
    </script>

</body>

</html>
